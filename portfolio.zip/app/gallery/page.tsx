import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Gallery3D } from "@/components/gallery-3d"
import { GalleryArt } from "@/components/gallery-art"

export default function GalleryPage() {
  return (
    <main className="container py-12 md:py-16">
      <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-8">Gallery</h1>

      <Tabs defaultValue="3d" className="w-full">
        <TabsList className="mb-8">
          <TabsTrigger value="3d">3D Renders</TabsTrigger>
          <TabsTrigger value="art">Art</TabsTrigger>
        </TabsList>
        <TabsContent value="3d">
          <Gallery3D />
        </TabsContent>
        <TabsContent value="art">
          <GalleryArt />
        </TabsContent>
      </Tabs>
    </main>
  )
}
