import { MusicPlayer } from "@/components/music-player"

export default function MusicPage() {
  return (
    <main className="container py-12 md:py-16">
      <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-8">Music</h1>

      <div className="grid gap-8">
        <p className="text-lg text-muted-foreground max-w-3xl">
          A collection of ambient compositions and experimental sound design exploring texture, space, and emotion.
        </p>

        <div className="grid gap-6">
          {musicTracks.map((track, index) => (
            <MusicPlayer key={index} title={track.title} description={track.description} duration={track.duration} />
          ))}
        </div>
      </div>
    </main>
  )
}

const musicTracks = [
  {
    title: "Ambient Reflections",
    description: "Atmospheric piece exploring layered textures and spatial elements",
    duration: "6:42",
  },
  {
    title: "Harmonic Drift",
    description: "Evolving drone composition with subtle melodic elements",
    duration: "8:15",
  },
  {
    title: "Spectral Memory",
    description: "Processed field recordings and synthesized textures",
    duration: "5:37",
  },
  {
    title: "Liminal Spaces",
    description: "Minimalist composition exploring the boundaries of perception",
    duration: "7:23",
  },
]
