import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { NameHeader } from "@/components/name-header"
import { FeaturedWork } from "@/components/featured-work"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex flex-col items-center justify-center px-4 py-24 md:py-32 lg:py-40">
        <NameHeader />
        <p className="mt-6 max-w-[42rem] text-center text-lg text-muted-foreground">
          Visual artist and musician exploring the boundaries between digital and physical spaces.
        </p>
        <div className="mt-8 flex gap-4">
          <Button asChild>
            <Link href="/gallery">
              View Gallery <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/music">Listen</Link>
          </Button>
        </div>
      </div>
      <FeaturedWork />
    </main>
  )
}
