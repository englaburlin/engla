export default function AboutPage() {
  return (
    <main className="container py-12 md:py-16">
      <div className="grid gap-8 md:grid-cols-2 md:gap-12">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">About</h1>
          <div className="space-y-4">
            <p>
              ENGLA WAHLBERG BURLIN is a multidisciplinary artist working at the intersection of digital and physical
              mediums. With a background in visual arts and sound design, her work explores themes of space, perception,
              and the relationship between technology and human experience.
            </p>
            <p>
              Her 3D renders investigate architectural forms and abstract spaces, often blurring the line between the
              real and the imagined. Her visual art practice encompasses digital painting, mixed media, and experimental
              techniques that challenge conventional approaches to image-making.
            </p>
            <p>
              As a musician and sound artist, she creates ambient compositions and experimental soundscapes that
              complement her visual work, creating immersive multi-sensory experiences that invite contemplation and
              emotional resonance.
            </p>
            <p>
              Based in Stockholm and Skellefteå, Sweden, her work continues to evolve through ongoing experimentation
              and a deep curiosity about the possibilities of digital tools as expressive mediums.
            </p>
          </div>
        </div>
        <div className="flex items-center justify-center">
          <div className="relative w-full max-w-md aspect-[3/4] overflow-hidden rounded-lg bg-muted flex items-center justify-center">
            <span className="text-muted-foreground">ENGLA WAHLBERG BURLIN</span>
          </div>
        </div>
      </div>
    </main>
  )
}
