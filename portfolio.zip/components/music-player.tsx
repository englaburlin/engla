"use client"

import { useState } from "react"
import { Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"

interface MusicPlayerProps {
  title: string
  description: string
  duration: string
  coverImage?: string
}

export function MusicPlayer({ title, description, duration }: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [volume, setVolume] = useState(80)

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = Math.floor(seconds % 60)
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Calculate current time based on progress and duration
  const durationParts = duration.split(":")
  const durationInSeconds = Number.parseInt(durationParts[0]) * 60 + Number.parseInt(durationParts[1])
  const currentTime = (progress / 100) * durationInSeconds

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-shrink-0">
            <div className="w-[150px] h-[150px] bg-muted rounded-md flex items-center justify-center">
              <span className="text-muted-foreground">{title}</span>
            </div>
          </div>
          <div className="flex flex-col flex-grow justify-between">
            <div>
              <h3 className="text-xl font-medium">{title}</h3>
              <p className="text-muted-foreground">{description}</p>
            </div>

            <div className="mt-4 space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground w-10">{formatTime(currentTime)}</span>
                <Slider
                  value={[progress]}
                  max={100}
                  step={1}
                  className="flex-grow"
                  onValueChange={(value) => setProgress(value[0])}
                />
                <span className="text-xs text-muted-foreground w-10">{duration}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" disabled>
                    <SkipBack className="h-4 w-4" />
                  </Button>
                  <Button onClick={togglePlay} size="icon" variant="outline">
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" disabled>
                    <SkipForward className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <Slider
                    value={[volume]}
                    max={100}
                    step={1}
                    className="w-24"
                    onValueChange={(value) => setVolume(value[0])}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
