import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

export function GalleryArt() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {galleryItems.map((item, index) => (
        <Dialog key={index}>
          <DialogTrigger asChild>
            <div className="cursor-pointer group overflow-hidden rounded-lg">
              <div className="aspect-square overflow-hidden bg-muted">
                <div className="flex h-full items-center justify-center">
                  <span className="text-muted-foreground">{item.title}</span>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-medium">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.medium}</p>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <div className="grid gap-4">
              <div className="aspect-video bg-muted flex items-center justify-center">
                <span className="text-muted-foreground">{item.title}</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold">{item.title}</h2>
                <p className="text-muted-foreground">{item.medium}</p>
                <p className="mt-2">{item.description}</p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      ))}
    </div>
  )
}

const galleryItems = [
  {
    title: "Color Study #4",
    medium: "Digital Painting",
    description: "Exploration of color relationships and emotional resonance through abstract forms.",
  },
  {
    title: "Fragmented Memory",
    medium: "Mixed Media",
    description: "A collage of digital and traditional techniques examining the nature of memory.",
  },
  {
    title: "Liminal Space",
    medium: "Digital Illustration",
    description: "Inspired by transitional spaces and the feeling of being between worlds.",
  },
  {
    title: "Texture Composition #7",
    medium: "Digital Collage",
    description: "An experiment in layering and texture using digital manipulation techniques.",
  },
  {
    title: "Chromatic Aberration",
    medium: "Digital Painting",
    description: "Playing with color separation and visual distortion as artistic elements.",
  },
  {
    title: "Gestural Forms",
    medium: "Digital Drawing",
    description: "Exploring movement and emotion through abstract gestural mark-making.",
  },
]
