import Link from "next/link"
import { Button } from "@/components/ui/button"

export function FeaturedWork() {
  return (
    <section className="w-full py-12 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Featured Work</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              A selection of my recent projects across different mediums.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
          {featuredItems.map((item) => (
            <Link
              key={item.title}
              href={item.href}
              className="group relative overflow-hidden rounded-lg shadow-lg transition-all hover:shadow-xl"
            >
              <div className="aspect-square overflow-hidden">
                <div className="h-full w-full bg-muted">
                  <div className="flex h-full items-center justify-center">
                    <span className="text-muted-foreground">{item.title}</span>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 transition-opacity group-hover:opacity-100">
                <div className="absolute bottom-0 w-full p-4">
                  <h3 className="text-xl font-bold text-white">{item.title}</h3>
                  <p className="text-sm text-white/80">{item.category}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
        <div className="flex justify-center">
          <Button variant="outline" asChild>
            <Link href="/gallery">View All Work</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

const featuredItems = [
  {
    title: "Ethereal Spaces",
    category: "3D Render",
    href: "/gallery/3d",
  },
  {
    title: "Color Study #4",
    category: "Digital Art",
    href: "/gallery/art",
  },
  {
    title: "Ambient Reflections",
    category: "Music",
    href: "/music",
  },
]
