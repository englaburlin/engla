import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

export function Gallery3D() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {galleryItems.map((item, index) => (
        <Dialog key={index}>
          <DialogTrigger asChild>
            <div className="cursor-pointer group overflow-hidden rounded-lg">
              <div className="aspect-square overflow-hidden bg-muted">
                <div className="flex h-full items-center justify-center">
                  <span className="text-muted-foreground">{item.title}</span>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-medium">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <div className="grid gap-4">
              <div className="aspect-video bg-muted flex items-center justify-center">
                <span className="text-muted-foreground">{item.title}</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold">{item.title}</h2>
                <p className="text-muted-foreground">{item.description}</p>
                <p className="mt-2">{item.details}</p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      ))}
    </div>
  )
}

const galleryItems = [
  {
    title: "Ethereal Spaces",
    description: "3D environment exploration",
    details: "Created using Blender with custom materials and lighting setup.",
  },
  {
    title: "Geometric Dreams",
    description: "Abstract architectural visualization",
    details: "A study in form and light using procedural textures.",
  },
  {
    title: "Organic Structures",
    description: "Biomorphic forms in digital space",
    details: "Inspired by natural growth patterns and cellular structures.",
  },
  {
    title: "Urban Fragments",
    description: "City-inspired abstract composition",
    details: "Exploring the relationship between architecture and light.",
  },
  {
    title: "Liquid Reflections",
    description: "Material study with fluid dynamics",
    details: "Experimenting with physically-based rendering and fluid simulations.",
  },
  {
    title: "Spatial Harmony",
    description: "Minimalist interior concept",
    details: "A meditation on negative space and subtle color gradients.",
  },
]
