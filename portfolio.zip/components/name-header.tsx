export function NameHeader() {
  return (
    <h1 className="animate-in text-center text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
      <span className="block">ENGLA</span>
      <span className="block mt-1">WAHLBERG BURLIN</span>
    </h1>
  )
}
